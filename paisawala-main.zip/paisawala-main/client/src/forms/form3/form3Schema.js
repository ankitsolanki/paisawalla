// Form 3 Schema - Updated to match CSV requirements exactly
// Note: Phone number is already authenticated via AuthForm
export default {
  // Single Step: All fields as per CSV
  fullName: {
    label: 'Full Name (As per Pan card)',
    type: 'text',
    required: true,
    rules: ['required', 'firstName'], // Reuse firstName validator for alphabets and space validation
    placeholder: 'Enter your full name as per PAN card',
    errorMessage: 'Please enter a valid full name',
    maxLength: 26,
  },
  panNumber: {
    label: 'PAN Number',
    type: 'text',
    required: true,
    rules: ['required', 'pan'], // Reuse Form1 PAN validation
    placeholder: 'Enter PAN number (e.g., ABCDE1234F)',
    errorMessage: 'Please Enter a Valid Pan',
    maxLength: 10,
  },
  dateOfBirth: {
    label: 'Date of Birth (DOB)',
    type: 'date',
    required: true,
    rules: ['required', 'dobDate'], // Reuse Form1 DOB validation
    placeholder: 'Select your date of birth',
    errorMessage: 'Please enter a valid Date of Birth',
  },
  pinCode: {
    label: 'Pin code',
    type: 'pincode',
    required: true,
    rules: ['required', 'zipCode'], // Reuse Form1 PIN code with API logic
    placeholder: 'Enter 6-digit PIN code',
    errorMessage: 'Please select a pin code',
    maxLength: 6,
    searchType: true,
    cityFieldName: 'city',
    stateFieldName: 'state',
  },
  loanAmount: {
    label: 'Desired Loan Amount',
    type: 'currency',
    required: true,
    rules: ['required', 'numeric', { type: 'min', params: [10000] }, { type: 'max', params: [100000000] }], // Reuse Form1 validation
    placeholder: 'Enter desired loan amount',
    errorMessage: 'Please provide a desired loan amount',
    min: 10000,
    max: 100000000,
  },
  employmentType: {
    label: 'Employment Type',
    type: 'select',
    required: true,
    rules: ['required'], // Reuse Form1 employment type
    placeholder: 'Select employment type',
    errorMessage: 'Please enter a valid Employment type',
    options: [
      { value: 'Salaried', label: 'Salaried' },
      { value: 'Self-employed professional', label: 'Self-employed professional' },
      { value: 'Self-employed business', label: 'Self-employed business' },
      { value: 'Student', label: 'Student' },
    ],
  },
  netMonthlyIncome: {
    label: 'Net Monthly Income',
    type: 'currency',
    required: true,
    rules: ['required', 'numeric', { type: 'min', params: [10000] }, { type: 'max', params: [10000000] }], // Reuse Form1 with 8-digit limit
    placeholder: 'Enter monthly income',
    errorMessage: 'This field is required(not more than 8 numeric digit)',
    min: 10000,
    max: 10000000,
  },
  
  // Auto-populated fields (still needed for pincode lookup)
  city: {
    label: 'City',
    type: 'text',
    required: true,
    rules: ['required', 'city'],
    placeholder: 'Select or enter city',
    errorMessage: 'Please select a city',
    searchType: true, // Auto Populated
  },
  state: {
    label: 'State',
    type: 'select',
    required: true,
    rules: ['required'],
    placeholder: 'Select state',
    errorMessage: 'Please select a state',
    searchType: true, // Auto Populated
    options: [
      { value: '1', label: 'Andhra Pradesh' },
      { value: '2', label: 'Arunachal Pradesh' },
      { value: '3', label: 'Assam' },
      { value: '4', label: 'Bihar' },
      { value: '5', label: 'Chhattisgarh' },
      { value: '6', label: 'Delhi' },
      { value: '7', label: 'Goa' },
      { value: '8', label: 'Gujarat' },
      { value: '9', label: 'Haryana' },
      { value: '10', label: 'Himachal Pradesh' },
      { value: '11', label: 'Jharkhand' },
      { value: '12', label: 'Karnataka' },
      { value: '13', label: 'Kerala' },
      { value: '14', label: 'Madhya Pradesh' },
      { value: '15', label: 'Maharashtra' },
      { value: '16', label: 'Manipur' },
      { value: '17', label: 'Meghalaya' },
      { value: '18', label: 'Mizoram' },
      { value: '19', label: 'Nagaland' },
      { value: '20', label: 'Odisha' },
      { value: '21', label: 'Punjab' },
      { value: '22', label: 'Rajasthan' },
      { value: '23', label: 'Sikkim' },
      { value: '24', label: 'Tamil Nadu' },
      { value: '25', label: 'Telangana' },
      { value: '26', label: 'Tripura' },
      { value: '27', label: 'Uttar Pradesh' },
      { value: '28', label: 'Uttarakhand' },
      { value: '29', label: 'West Bengal' },
      { value: '30', label: 'Puducherry' },
    ],
  },
};

